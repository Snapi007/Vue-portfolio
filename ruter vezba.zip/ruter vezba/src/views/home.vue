<script setup>
import { ref } from "vue";
const selected = ref(0);
const hover = ref(false);
const time = ref(0);
const activ = ref(false);
setInterval(() => {
  
  if(activ.value==true)
  time.value = time.value + 0.01;
}, 10);
</script>
<template>
  <div class="image-wraper">
    <img
      class="background-image"
      src="../assets/images/atletska-staza.jpg"
      alt=""
    />
    <div class="image-overly">
      <div class="image-navigation">
        <span
          class="span-link"
          :class="selected == 0 ? 'highlighted' : ''"
          @click="selected = 0"
          >Tekst 1</span
        >
        <span
          class="span-link"
          :class="selected == 1 ? 'highlighted' : ''"
          @click="selected = 1"
          >Tekst 2</span
        >
        <span
          class="span-link"
          :class="selected == 2 ? 'highlighted' : ''"
          @click="selected = 2"
          >Teskt 3</span
        >
      </div>
      <div class="tekst-div">
        <div v-if="selected == 0">
          Sed ut perspiciatis unde omnis iste natus error sit voluptatem
          accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae
          ab illo inventore veritatis et quasi architecto beatae vitae dicta
          sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit
          aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos
          qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui
          dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.
        </div>
        <div v-if="selected == 1">
          Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis
          suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis
          autem vel eum iure reprehenderit qui in ea voluptate velit esse quam
          nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo
          voluptas nulla pariatur?
        </div>
        <div v-if="selected == 2">
          At vero eos et accusamus et iusto odio dignissimos ducimus qui
          blanditiis praesentium voluptatum deleniti atque corrupti quos dolores
          et quas molestias excepturi sint occaecati cupiditate non provident,
          similique sunt in culpa qui officia deserunt mollitia animi, id est
          laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita
          distinctio. Nam libero tempore, cum soluta nobis est eligendi optio
          cumque nihil impedit quo minus id quod maxime placeat facere possimus,
          omnis voluptas assu
        </div>
      </div>
    </div>
    <div class="flex">
      <img
        class="sat"
        :class="hover ? 'big-clock' : ''"
        src="https://visualpharm.com/assets/793/Smart%20Watch-595b40b65ba036ed117d3b82.svg"
        @click="activ=!activ"
        @mouseenter="hover = true"
        @mouseleave="hover = false"
        alt=""
      />
      <div class="time">{{ time.toFixed(2) }}</div>

      <img
        class="background-image2 img2"
        src="../assets/images/Usain-bolt.jpg"
        alt=""
      />

      <img
        class="img2"
        src="../assets/images/Patike za trcanje.jpg.png"
        alt=""
      />

      <img class="img2" src="../assets/images/Start za sprint.jpg.png" alt="" />
    </div>
    <div class="flex" style="height: 100px">
      <div style="background-color: #014743; width: 16.67%"></div>
      <div style="background-color: #1d1d1e; width: 16.67%"></div>
      <div style="background-color: #311110; width: 16.67%"></div>
      <div style="background-color: #a20616; width: 16.67%"></div>
      <div style="background-color: #a58681; width: 16.67%"></div>
      <div style="background-color: #6c6846; width: 16.67%"></div>
    </div>
  </div>
</template>

<style lang="css" scoped>
.Home-heder {
  z-index: 10;
  position: relative;
}
.background-image {
  width: 100%;
  position: relative;
  top: 0;
  left: 0;
  z-index: 0;
}

.image-wraper {
  position: relative;
  width: 100%;
}
.image-overly {
  width: 100%;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 10;
}
.image-navigation {
  width: fit-content;
  margin: auto;
  margin-top: 25px;
  margin-bottom: 25px;
}
.span-link {
  margin-left: 15px;
  margin-right: 15px;
  font-size: 25px;
  font-weight: bold;
  cursor: pointer;
}
.tekst-div {
  width: 50%;
  margin: auto;
}
.highlighted {
  color: orangered;
}
.background-image2 {
  position: relative;
}
.img2 {
  width: 33.33%;
}
.flex {
  display: flex;
}
.sat {
  position: absolute;
  left: 33%;
  transform: translateX(-50%) translateY(-50%);
  width: 33%;
  z-index: 10;
  cursor: pointer;
}
.time {
  background-color: black;
  width: fit-content;
  height: fit-content;
  border-radius: 10px;
  position: absolute;
  left: 33%;
  transform: translateX(-50%) translateY(-50%);
  z-index: 20;
  cursor: pointer;
  font-size: 40px;
  color: #08870e;
}

.big-clock {
  transform: translateX(-50%) translateY(-50%) scale(1.3);
}
</style>
