<script setup>
import { ref, onMounted } from "vue";
import { data } from "../data/business";
const localdata = ref([]);
const newbusines = ref({
  name: "",
  abn: "",
  location: "",
  industry: "",
  description: "",
  email: "",
  phone: "",
});
const addbusines = () => {
    localdata.value.push(newbusines.value)
    newbusines.value={
  name: "",
  abn: "",
  location: "",
  industry: "",
  description: "",
  email: "",
  phone: "",
}
}

onMounted(() => {
  data.forEach((element) => {
    localdata.value.push(element);
  });
});
</script>
<template>
  <div class="addbusines">
    <div class="input-row">
      <label class="label" for="">Name:</label><input type="text" v-model="newbusines.name" />
    </div>
    <div class="input-row">
      <label class="label" for="">abn:</label><input type="text" v-model="newbusines.abn" />
    </div>
    <div class="input-row">
      <label class="label" for="">location:</label><input type="text" v-model="newbusines.location" />
    </div>
    <div class="input-row">
      <label class="label" for="">industry:</label><input type="text" v-model="newbusines.industry" />
    </div>
    <div class="input-row">
      <label class="label" for="">description:</label><input type="text" v-model="newbusines.description" />
    </div>
    <div class="input-row">
      <label class="label" for="">email:</label><input type="text" v-model="newbusines.email" />
    </div>
    <div class="input-row">
      <label class="label" for="">phone:</label><input type="text" v-model="newbusines.phone" />
    </div>
    <button class="btn" @click="addbusines">Add</button>
  </div>
  
  <table class="table">
    <tr class="row">
      <th>Name</th>
      <th>Location</th>
      <th>Industry</th>
      <th>E-mail</th>
      <th>Phone</th>
    </tr>
    <tr v-for="element in localdata" class="row">
      <td>{{ element.name }}</td>
      <td>{{ element.location }}</td>
      <td>{{ element.industry }}</td>
      <td>{{ element.email }}</td>
      <td>{{ element.phone }}</td>
    </tr>
  </table>
</template>

<style lang="css" scoped>
.table {
 
  margin: auto;
  padding-top: 20px;
  padding-bottom: 20px;
}
.row {
  padding-top: 5px;
  padding-bottom: 5px;
  background-color: aquamarine;
}
.input-row {
  display: flex;
  padding-top: 10px;
  
}
.label {
    width: 150px;
}
.addbusines {
    width: fit-content;
    margin: auto;
    padding-top: 30px;
}
.btn {
    margin: auto;
    margin-top: 10px;
    margin-bottom: 10px;
    width: 80px;
    height: 30px;
    border: 2px solid black;
    border-radius: 5px;
    background-color: #32a852;
    cursor: pointer;
}
th,td {
    padding: 12px;
    text-align: left;
    border: 1px solid #32a852;
}
th {
    background-color: rgb(17, 136, 23);
    color: #fff;
}
tr:hover {
    background-color: #e0e0e0;
}
</style>
