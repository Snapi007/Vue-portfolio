<script setup></script>

<template>
  <div class="profile-header">
    <p style="width: 1300px; margin:auto">Nikola Tomic</p>
  </div>
  <div class="profile-body">
    <div class="profil-column">
      <img
        style="width: 400px"
        src="../views/lion-with-rainbow-mane-blue-eyes_1340-39421.avif"
        alt=""
      />
      <div
        style="
          width: 400px;
          padding: 15px;
          background-color: #ffcb3d;
          box-sizing: border-box;
        "
      >
        Sed ut perspiciatis unde omnis iste natus error sit voluptatem
        accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab
        illo inventore veritatis et quasi architecto beatae vitae dicta sunt
        explicabo. Nemo enim ipsam voluptatem quia .
      </div>
      <div style="padding-top: 20px; padding-bottom: 20px">
        <div class="p-row">
          <div class="left-row">AGE</div>
          <div class="right-row">38</div>
        </div>
        <div class="p-row">
          <div class="left-row">PROFESION</div>
          <div class="right-row">Web developer</div>
        </div>
        <div class="p-row">
          <div class="left-row">STATUS</div>
          <div class="right-row">Maried</div>
        </div>
        <div class="p-row">
          <div class="left-row">LOCATION</div>
          <div class="right-row">Bruneck</div>
        </div>
        <div class="p-row">
          <div class="left-row">HOBBY</div>
          <div class="right-row">Running</div>
        </div>
        <div class="p-row">
          <div class="left-row">NAME AND SURNAME</div>
          <div class="right-row">Nikola Tomic</div>
        </div>
      </div>
      <div>
        <div style="display: flex">
          <div class="tag">Creative</div>
          <div class="tag">Inteligent</div>
        </div>
        <div style="display: flex">
          <div class="tag">Productive</div>
          <div class="tag">Hard working</div>
        </div>
      </div>
    </div>
    <div class="profil-column">
      <div class="bio">
        <h3>Bio</h3>
        <p>
          Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
          consectetur, adipisci velit, sed quia non numquam eius modi tempora
          incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut
          enim ad minima veniam, quis nostrum exercitationem ullam corporis
          suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis
          autem vel eum iure reprehenderit qui in ea voluptate velit esse quam
          nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo
          voluptas nulla pariatur.
        </p>
      </div>
      <div class="personality">
        <h3>Personality</h3>
        <div class="personality-label">
          <span>introvert</span><span>ekstrovert</span>
        </div>
        <input
          type="range"
          min="1"
          max="100"
          value="90"
          class="slider"
          id="myRange"
        />
        <div class="personality-label">
          <span>Intuitive</span><span>Sensing</span>
        </div>
        <input
          type="range"
          min="1"
          max="100"
          value="50"
          class="slider"
          id="myRange"
        />
        <div class="personality-label">
          <span>Thinking</span><span>feeling</span>
        </div>
        <input
          type="range"
          min="1"
          max="100"
          value="20"
          class="slider"
          id="myRange"
        />
        <div class="personality-label">
          <span>Judging</span><span>Perceiving</span>
        </div>
        <input
          type="range"
          min="1"
          max="100"
          value="75"
          class="slider"
          id="myRange"
        />
      </div>
    </div>
    <div class="profil-column">
      <div class="lists">
        <h3>Goals</h3>
        <ol>
          <li>perspiciatis unde omnis</li>
          <li>architecto beatae vitae dicta</li>
          <li>Ut enim ad minima veniam</li>
        </ol>
        <h3>Frustrations</h3>
        <ul>
          <li>eiusmod tempor incididunt</li>
          <li>commodo consequat</li>
          <li>Duis aute irure dolor in reprehenderit</li>
        </ul>
      </div>
      <div class="motivations">
        <h3>Motivations</h3>
        <div class="motivations-row">
          <div class="motivations-label">Price</div>
          <div class="motivations-data">
            <div
              style="height: 20px; width: 60%; background-color: #ffcb3d"
            ></div>
          </div>
        </div>
        <div class="motivations-row">
          <div class="motivations-label">Saves Time</div>
          <div class="motivations-data">
            <div
              style="height: 20px; width: 95%; background-color: #ffcb3d"
            ></div>
          </div>
        </div>
        <div class="motivations-row">
          <div class="motivations-label">Ease of Use</div>
          <div class="motivations-data">
            <div
              style="height: 20px; width: 87%; background-color: #ffcb3d"
            ></div>
          </div>
        </div>
        <div class="motivations-row">
          <div class="motivations-label">Creativity</div>
          <div class="motivations-data">
            <div
              style="height: 20px; width: 90%; background-color: #ffcb3d"
            ></div>
          </div>
        </div>
        <div class="motivations-row">
          <div class="motivations-label">Uniqueness</div>
          <div class="motivations-data">
            <div
              style="height: 20px; width: 80%; background-color: #ffcb3d"
            ></div>
          </div>
        </div>
      </div>
      <div class="motivations">
        <h3>Tehnology</h3>
        <p>IT & internet</p>
        <div class="tehnology-data">
          <div
            style="width: 67%; background-color: #ffcb3d; height: 100%"
          ></div>
        </div>
        <p>Design Software</p>
        <div class="tehnology-data">
          <div
            style="width: 87%; background-color: #ffcb3d; height: 100%"
          ></div>
        </div>
        <p>Mobile Apps</p>
        <div class="tehnology-data">
          <div
            style="width: 27%; background-color: #ffcb3d; height: 100%"
          ></div>
        </div>
        <p>Social Media</p>
        <div class="tehnology-data">
          <div
            style="width: 47%; background-color: #ffcb3d; height: 100%"
          ></div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="css" scoped>
.profile-header {
  background-color: #ffcb3d;
  padding: 15px;
  font-size: 24px;
  font-weight: bold;
}
.profile-body {
  width: 1300px;
  margin: auto;
  display: flex;
}
.profil-column {
  width: 400px;
  margin-left: 25px;
  margin-top: 25px;
  background-color: #eee;
  height: 100%;
  margin-bottom: 25px;
}
.p-row {
  display: flex;
}
.left-row {
  width: 190px;
  margin-right: 10px;
  text-align: right;
  font-size: 16px;
  font-weight: bold;
  color: #ed4815;
}
.right-row {
  width: 190px;
  margin-left: 10px;
  text-align: left;
  font-size: 16px;
}
.tag {
  width: 160px;
  margin-left: 20px;
  margin-right: 20px;
  text-align: center;
  border-radius: 10px;
  margin-top: 10px;
  margin-bottom: 10px;
  font-size: 18px;
  font-weight: bold;
  background-color: #ffcb3d;
  padding-top: 10px;
  padding-bottom: 10px;
}
.bio {
  margin-left: 15px;
  margin-right: 15px;
}
.lists {
  margin-left: 15px;
  margin-right: 15px;
}
.personality {
  margin-left: 15px;
  margin-right: 15px;
}
.personality-label {
  display: flex;
  justify-content: space-between;
}
.slider {
  -webkit-appearance: none;
  width: 100%;
  height: 25px;
  background: #b8ece4;
  outline: none;
  opacity: 0.7;
  -webkit-transition: 0.2s;
  transition: opacity 0.2s;
}
.slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 25px;
  height: 25px;
  background: #ffcb3d;
  cursor: pointer;
}
.slider::-moz-range-thumb {
  width: 25px;
  height: 25px;
  background: #ffcb3d;
  cursor: pointer;
}
.slider:hover {
  opacity: 1;
}
.motivations-row {
  margin-bottom: 5px;
  display: flex;
}
.motivations-label {
  width: 30%;
  padding-right: 5px;
  text-align: right;
}
.motivations-data {
  width: 70%;
  padding-left: 5px;
}
.motivations {
  margin-left: 15px;
  margin-right: 15px;
}
.tehnology-data {
  height: 20px;
  background-color: #b8ece4;
}
</style>
