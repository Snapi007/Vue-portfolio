<script setup>
import {ref} from "vue"

import layoutdesktop from './layout/layoutdesktop.vue';
import layoutmobile from './layout/layoutmobile.vue';
const ismobile = ref(false)

const calculateversion = () => {
if(window.innerWidth<=768){
  ismobile.value=true
}else{
  ismobile.value=false
}
}
const init = () => {
  window.addEventListener("resize", calculateversion)
  calculateversion()
}
init()
</script>

<template>
<layoutdesktop v-if="!ismobile"/>
<layoutmobile v-if="ismobile"/>
</template>

<style lang="css" scoped>


</style>
