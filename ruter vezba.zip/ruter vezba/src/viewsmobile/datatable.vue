<script setup>
</script>
<template>
<h1>Datatable</h1>
</template>

<style lang="css" scoped>

</style>