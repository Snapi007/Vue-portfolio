<script setup>
import { RouterLink, RouterView } from 'vue-router'
import router from '../router';
</script>

<template>
    <div class="header">
<router-link to="/" class="heder-link">Home</router-link>
<router-link to="/about" class="heder-link">About me</router-link>
<router-link to="/help" class="heder-link">Help</router-link>
</div>
  <RouterView class="offset" name="mobile"/>
  <div class="footer">
<div class="half">
  <img class="icon-img" src="./assets/images/unnamed3.png" alt="">
  <img class="icon-img" src="./assets/images/unnamed.png" alt="">
  <img class="icon-img" src="./assets/images/unnamed2.png" alt="">
</div>
<div class="half">Šta je Indeks telesne mase ili BMI?
 Koliki je vaš BMI? Šta to znaći i šta možete
 da uradite ako je povećan? – 
BMI KALKULATOR
	Indeks telesne mase ili skraćeno BMI je statistički pokazatelj uhranjenosti pojedinca. 
On stavlja u odnos težinu i visini, a primenjiv je za sve osobe starije od 20 godina. Iako ne 
prikazuje procenat masti u organizmu, BMI je koristan.
Formula po kojoj se računa indeks telesne mase:
	BMI je odnos vaše mase i visine. Izračunava se jednostavno kada podelite masu
 vašeg tela izraženu u kilogramima sa kvadratom vaše visine izražene u metrima.
</div>
  </div>
</template>

<style lang="css" scoped>

.half {
  display: flex;
  justify-content: space-between;
  width: 50%;
  padding: 20px;
  background-color: #E8DDDD;
}

.icon-img {
  width: 25%;
}
.footer {
  display: flex;
}
.header {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 60px;
  background-color: yellow;
  display: flex;
  z-index: 100;
}
.offset {
  margin-top: 60px;
}

.heder-link {
  height: 60px;
  margin-left: 25px;
  font-size: 26px;
  color: black;
  font-weight: bold;
  display: flex;
  justify-content: center;
  align-items: center;
  text-decoration: none;
}

.heder-link:hover {
color: yellow;
}

</style>