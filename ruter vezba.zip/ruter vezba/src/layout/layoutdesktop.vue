<script setup>
import { RouterLink, RouterView } from "vue-router";
import router from "../router";
</script>

<template>
  <div class="header">
    <router-link to="/" class="heder-link">Home</router-link>
    <router-link to="/about" class="heder-link">About me</router-link>
    <router-link to="/help" class="heder-link">Help</router-link>
    <router-link to="/gkn" class="heder-link">GKN</router-link>
    <router-link to="/datatable" class="heder-link">Datatable</router-link>

    <form
      class="form-container gkn-link"
      action="https://www.google.com/search"
      method="get"
      target="_blank"
    >
      <div>
        <p>
          <input
            type="text"
            name="sve"
            class="search-bar"
            placeholder="google search"
          />
          <button type="submit">search</button>
        </p>
      </div>
    </form>
  </div>
  <div class="offset"><RouterView /></div>

  <div class="footer">
    <div class="half">
      <img class="icon-img" src="../assets/images/sat garmin.jpg.png" alt="" />
      <img class="icon-img" src="./assets/images/unnamed.png" alt="" />
 
      <p></p>
      <img class="icon-img" src="../assets/logo.svg" alt="" />
    </div>
    <div class="half">
      Šta je Indeks telesne mase ili BMI? Koliki je vaš BMI? Šta to znaći i šta
      možete da uradite ako je povećan? – BMI KALKULATOR Indeks telesne mase ili
      skraćeno BMI je statistički pokazatelj uhranjenosti pojedinca. On stavlja
      u odnos težinu i visini, a primenjiv je za sve osobe starije od 20 godina.
      Iako ne prikazuje procenat masti u organizmu, BMI je koristan. Formula po
      kojoj se računa indeks telesne mase: BMI je odnos vaše mase i visine.
      Izračunava se jednostavno kada podelite masu vašeg tela izraženu u
      kilogramima sa kvadratom vaše visine izražene u metrima.
    </div>
  </div>
</template>

<style lang="css" scoped>
.search-bar {
  border-radius: 10%;
}
.half {
  display: flex;
  justify-content: space-between;
  width: 50%;
  padding: 20px;
  background-color: #e8dddd;
}

.icon-img {
  width: 25%;
}
.footer {
  display: flex;
}
.header {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 60px;
  background-color: aquamarine;
  display: flex;
  z-index: 100;
}
.offset {
  margin-top: 60px;
}

.heder-link {
  height: 60px;
  margin-left: 25px;
  font-size: 26px;
  color: black;
  font-weight: bold;
  display: flex;
  justify-content: center;
  align-items: center;
  text-decoration: none;
}

.heder-link:hover {
  color: yellow;
}
.gkn-link {
  margin-left: auto;
}

.form-container {
  display: flex;
  justify-content: flex-end;
  padding: 10px;
  background-color: rgb(46, 223, 61);
  position: relative;
  border-radius: 20px;
}

</style>
