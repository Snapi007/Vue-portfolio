import { createRouter, createWebHistory } from 'vue-router'


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
   components: {
    default:() => import("../views/home.vue"),
    mobile:() => import("../viewsmobile/home.vue"),
   }
    },
    {
      path: '/about',
      name: 'about',
      components: {
        default:() => import("../views/aboutme.vue"),
        mobile:() => import("../viewsmobile/aboutme.vue"),
       }
    },
    {
      path: '/help',
      name: 'help',
      components: {
        default:() => import("../views/help.vue"),
        mobile:() => import("../viewsmobile/help.vue"),
       }
    },
    {
      path: '/gkn',
      name: 'gkn',
      components: {
        default:() => import("../CV-autobiografija/gkn.vue"),
        mobile:() => import("../CV-autobiografija/gkn.vue"),
       }
    },
    {
      path: '/nova-stranica',
      name: 'nova-stranica',
      components: {
        default:() => import("../CV-autobiografija/nova-stranica.vue"),
        mobile:() => import("../CV-autobiografija/nova-stranica.vue"),
       }
      },
    {
      path: '/datatable',
      name: 'datatable',
      components: {
        default:() => import("../views/datatable.vue"),
        mobile:() => import("../viewsmobile/datatable.vue"),
      }
    }
  ]
})

export default router
