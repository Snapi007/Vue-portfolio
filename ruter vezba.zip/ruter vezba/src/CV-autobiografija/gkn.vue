<script setup>
import { ref } from "vue";
const selected = ref(0);
const hover = ref(false);
const time = ref(0);
const activ = ref(false);
</script>
<template>
  <div id="body">
    <img
      class="background-images"
      src="../CV-autobiografija/slike za GKN/Naslovna slika.jpg"
      alt="slova"
    />
    <button class="overlay-button">
      <a href="https://www.gknautomotive.com/">Apply for feautures</a>
    </button>
    <div class="flex-container">
      <div class="diamond-container">
        <p class="diamont-text">neki tekst</p>
      </div>
      <div class="diamond-container">
        <p class="diamont-text">neki tekst</p>
      </div>
      <div class="diamond-container">
        <p class="diamont-text">neki tekst</p>
      </div>
      <div class="diamond-container">
        <p class="diamont-text">neki tekst</p>
      </div>
      <div class="diamond-container">
        <p class="diamont-text">neki tekst</p>
      </div>
      <div class="diamond-container">
        <p class="diamont-text">neki tekst</p>
      </div>
      <div class="diamond-container">
        <p class="diamont-text">neki tekst</p>
      </div>
      <div class="diamond-container">
        <p class="diamont-text">neki tekst</p>
      </div>
    </div>

    <button class="overlay-button1">
      <a href="https://www.gknautomotive.com/">New Tehnology</a>
    </button>
  </div>
  <div class="flex">
    <img
      class="slika1"
      src="../CV-autobiografija/slike za GKN/Gkn_Driveline_India_Ltd.jpg"
      alt="slova"
    />
    <img
      class="slika1"
      src="../CV-autobiografija/slike za GKN/gkn-driveline-etwinsterx-awd-phev_YEh3gn3_biggalleryimage.jpg"
      alt="unutrasnjost karoserije"
    />
    <img
      class="slika1"
      src="../CV-autobiografija/slike za GKN/drive_lg.jpg"
      alt="maketa motora"
    />
  </div>
  <div class="pravougaonik TEXT">
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ipsum
    sapien, varius ut porta porta, congue et tellus. Mauris porta,
    <a href="https://www.audi.it/it/web/it.html">AUDI</a> nunc non bibendum
    fringilla, nisl orci dignissim sem, ut hendrerit nisi lectus vitae tellus.
    Nulla elit leo, auctor vitae nisl ut, porttitor euismod justo. Fusce aliquam
    quis nisi non elementum. Ut a pretium arcu, at egestas metus. Vivamus ex
    odio, viverra in placerat ut, fermentum vitae augue. Interdum et malesuada
    fames ac ante ipsum primis in faucibus. Mauris maximus, velit nec tincidunt
    sagittis, turpis lorem vestibulum augue, non suscipit nisi magna sit amet
    ex.
  </div>

  <div></div>
  <div class="flex">
    <img
      class="slika1"
      src="../CV-autobiografija/slike za GKN/gettyimages-514339076-2048x2048.jpg"
      alt="slova"
    />
    <P>
      <div id="">
        <ul>
          <li><a href="">DISCIPLIN</a></li>
          <li>
            <a
              href="https://www.wfo-bruneck.info/images/schule/veranstaltungen/schuljahr_2016_17/gkn_03.jpg"
              >QUALITET</a
            >
          </li>
          <li>
            <a
              href="https://scienceexchange.caltech.edu/topics/artificial-intelligence-research"
              >RESEARCH</a
            >
          </li>
          <li>
            <a
              href="https://www.gknautomotive.com/en/media-centre/news-releases/2023/gkn-automotive-unveils-new-off-the-shelf--electric-drive-unit-concept/"
              >NEW PRODUCT</a
            >
          </li>
          <li><a href="">FEAUTURES</a></li>
        </ul>
      </div>
    </P>

    <img
      class="slika1"
      src="../CV-autobiografija/slike za GKN/9.jpg"
      alt="maketa motora"
    />
  </div>

  <footer>
    <div class="container">
      <div class="social-network column"><span class="red-text">GKN</span>
      <div class="dropdown">
        <div class="dropdown-btn">Opcije</div>
        <div class="dropdown-content">
          <div>1</div>
          <div>2</div>
          <div>3</div>
        </div>
      </div>
      </div>
      <div><a href="https://www.whatsapp.com/"> nesto novo</a></div>
      <div>mogucnosti</div>
      <a href="https://www.gknautomotive.com/">feautures</a>

      <p>
        <label for="mail">E-mail</label>
        <input type="email" name="mail" id="mail" required />
      </p>
      <p><input type="text" name="tekst" placeholder="BEWIRB DICH HIER" /></p>
    </div>
  </footer>
</template>

<style lang="css" scoped>
#body {
  background-color: #7fffd4;
}
.background-images {
  position: relative;
  width: 100%;
  display: inline-block;
}
.container {
  margin-top: 50px;
  display: flex;
  justify-content: space-around;
  align-items: stretch;
  height: 10vh;
}
.flex {
  display: flex;
  justify-content: space-around;
}
.slika1 {
  width: 33.33%;
}
.pravougaonik {
  margin: 0;
  padding: 0;
  height: 10vh;
  width: 100%;
  flex-direction: column;
  background-color: rgb(68, 0, 255);
  color: rgb(187, 241, 241);
  flex: 1;
  background: linear-gradient(
    to bottom,
    #3498db,
    #ffffff
  ); /* Prilagodite boje prema vašim željama */
  width: 100%;
}
.overlay-button {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  padding: 10px 20px;
  background-color: #2fbeab;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
.overlay-button1 {
  position: absolute;
  top: 0;
  left: 0;
  padding: 10px 20px;
  transform: translate(-50%, -50%);
  background-color: transparent;
  color: #4caf50;
  border: 2px solid #4caf50;
  border-radius: 5px;
  cursor: pointer;
}
.overlay {
  position: absolute;
  top: 50%;
  left: 50%;
  height: 50%;
  width: 50%;
  transform: translate(-50%, -50%);
}
.flex {
  display: flex;
  height: 50%;
}
.dimenzion {
  display: flex;
  width: 33%;
  height: 100%;
  justify-content: center;
  align-items: center;
}
.hex {
  margin-top: 30px;
  width: 180px;
  height: 60px;
  background-color: #27aae1;
  border-color: #27aae1;
  position: relative;
  display: inline-block;
}
.hex:before {
  content: " ";
  width: 0;
  height: 0;
  border-bottom: 30px solid;
  border-color: inherit;
  border-left: 90px solid transparent;
  border-right: 90px solid transparent;
  position: absolute;
  top: -30px;
}
.hex:after {
  content: "";
  width: 0;
  position: absolute;
  bottom: -30px;
  border-top: 30px solid;
  border-color: inherit;
  border-left: 90px solid transparent;
  border-right: 90px solid transparent;
}

.diamond-container {
  position: relative;
  width: 100px;
  height: 100px;
  background-color: #3498db;
  transform: rotate(45deg);
  margin: 20px;
}

.diamond-text {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-45deg);
  color: #fff;
  text-align: center;
  width: 100%;
  margin: 20px;
  transition: transform 0.3s ease;
}

.flex-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}
.red-text {
  color: red;
  cursor: pointer;
}
.TEXT {
  color: #eb9514;
}
.img1 {
  margin-top: 30px;
  margin-bottom: 30px;
  margin-left: 50px;
  width: 33%;
}
.social-network {
  position: relative;
}
.dropdown {
  position: absolute;
  top: 100%;
  left: 0;
  display: none;
}
.red-text:hover + .dropdown {
  display: block;
}
.dropdown-btn {
  cursor: pointer;
  padding: 10px;
  background-color: #f0f0f0;
  border: 1px solid #ccc;
}

.dropdown-content {
  display: none;
  position: absolute;
  top: 100%;
  left: 0;
  background-color: #fff;
  border: 1px solid #ccc;
}

.dropdown-content div {
  padding: 10px;
  border-bottom: 1px solid #ccc;
}
.dropdown:hover .dropdown-content {
  display: block;
}
</style>
