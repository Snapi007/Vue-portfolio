<script setup>
import { ref } from "vue";
const selected = ref(0);
const hover = ref(false);
const time = ref(0);
const activ = ref(false);
</script>
<template>
    
</template>
<style lang="css" scoped>

</style>